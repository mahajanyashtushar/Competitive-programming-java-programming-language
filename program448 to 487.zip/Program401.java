import java.util.*;
import java.io.*;

class Program401
{
    public static void main(String Ar[])
    {
        Scanner sobj = new Scanner(System.in);

        System.out.println("Enter file name : ");
        String FileName = sobj.nextLine();

        System.out.println("File name is : "+FileName);
    }
}